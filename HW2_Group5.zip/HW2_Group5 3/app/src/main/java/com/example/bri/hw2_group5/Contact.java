package com.example.bri.hw2_group5;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by Bri on 9/30/2017.
 */

public class Contact implements Serializable, Parcelable {
    private String fname, lname, company, phone, email, url, address, bday, nname, facebook, twitter, skype, youtube;
    private int avatarID;


    public Contact(String fname, String lname, String company, String phone, String email, String url, String address, String bday, String nname, String facebook, String twitter, String skype, String youtube, int avatarID) {
        this.fname = fname;
        this.lname = lname;
        this.company = company;
        this.phone = phone;
        this.email = email;
        this.url = url;
        this.address = address;
        this.bday = bday;
        this.nname = nname;
        this.facebook = facebook;
        this.twitter = twitter;
        this.skype = skype;
        this.youtube = youtube;
        this.avatarID = avatarID;
    }

    protected Contact(Parcel in){
        this.fname = in.readString();
        this.lname = in.readString();
        this.company = in.readString();
        this.phone = in.readString();
        this.email = in.readString();
        this.url = in.readString();
        this.address = in.readString();
        this.bday = in.readString();
        this.nname = in.readString();
        this.facebook = in.readString();
        this.twitter = in.readString();
        this.skype = in.readString();
        this.youtube = in.readString();
        this.avatarID = in.readInt();
    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override
        public Contact createFromParcel(Parcel in) {
            return new Contact(in);
        }

        @Override
        public Contact[] newArray(int size) {
            return new Contact[size];
        }
    };

    public int getAvatarID() {
        return avatarID;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getCompany() {
        return company;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getUrl() {
        return url;
    }

    public String getAddress() {
        return address;
    }

    public String getBday() {
        return bday;
    }

    public String getNname() {
        return nname;
    }

    public String getFacebook() {
        return facebook;
    }

    public String getTwitter() {
        return twitter;
    }

    public String getSkype() {
        return skype;
    }

    public String getYoutube() {
        return youtube;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fname);
        dest.writeString(lname);
        dest.writeString(company);
        dest.writeString(phone);
        dest.writeString(email);
        dest.writeString(url);
        dest.writeString(address);
        dest.writeString(bday);
        dest.writeString(nname);
        dest.writeString(facebook);
        dest.writeString(twitter);
        dest.writeString(skype);
        dest.writeString(youtube);
        dest.writeInt(avatarID);
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBday(String bday) {
        this.bday = bday;
    }

    public void setNname(String nname) {
        this.nname = nname;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public void setSkype(String skype) {
        this.skype = skype;
    }

    public void setYoutube(String youtube) {
        this.youtube = youtube;
    }

    public void setAvatarID(int avatarID) {
        this.avatarID = avatarID;
    }
}
