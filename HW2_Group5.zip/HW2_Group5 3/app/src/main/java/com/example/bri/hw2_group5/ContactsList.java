package com.example.bri.hw2_group5;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ContactsList extends AppCompatActivity {

    private ArrayList<Contact> myContacts;
    private int nextAction;
    public final static int REQ_CODE_EDIT_VIEW = 200;
    public final static String EDIT_INDEX = "Index";
    public final static String CONTACT = "CONTACT";

    public final static String CONTACT_LIST= "CONTACT_LIST";

    ArrayAdapter<Contact> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts_list);

        myContacts = (ArrayList<Contact>) getIntent().getSerializableExtra(MainActivity.CONTACT_LIST);
        nextAction = getIntent().getExtras().getInt(MainActivity.WHAT_DO);

        if(myContacts == null)
        {
            Log.e("contactsList", "contacts is null! :(");
            return;
        }

        adapter = new MyListAdapter();
       ListView list = (ListView) findViewById(R.id.contactListView);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int position, long l) {

                //We are Editing a Contact.
                if(nextAction == MainActivity.REQ_CODE_EDIT){
                    //Sends the contact we want to edit + the current index.
                    Intent editIntent = new Intent(ContactsList.this, EditContact.class);
                    Contact selected = adapter.getItem(position);
                    editIntent.putExtra(CONTACT, (Parcelable) selected);
                    editIntent.putExtra(EDIT_INDEX, position);
                    startActivityForResult(editIntent, REQ_CODE_EDIT_VIEW);
                }

                //Deleting a Contact. Prompt the user and send back the choice to MainActivity.
                else if(nextAction == MainActivity.REQ_CODE_DELETE){
                    final Contact deleteContact = adapter.getItem(position);
                    final int index = position;
                    AlertDialog.Builder deleteDialog = new AlertDialog.Builder(view.getContext());
                    String[] arrayChoice = {"Yes", "No"};
                    deleteDialog.setTitle(R.string.deletePrompt).setItems(arrayChoice, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            if(which == 0){ //Means Yes was selected.
                                Intent returnIntent = new Intent();
                                returnIntent.putExtra(MainActivity.CONTACT, (Parcelable) deleteContact);
                                returnIntent.putExtra(MainActivity.EDIT_INDEX, index);
                                setResult(RESULT_OK, returnIntent);
                                finish();
                            }
                            Log.d("contactslist", Integer.toString(which));

                            //returnIntent.putExtra(MainActivity.CONTACT, (Parcelable) )
                        }
                    });
                    AlertDialog alert = deleteDialog.create();
                    alert.show();
                }

                else if(nextAction == MainActivity.REQ_CODE_DISPLAY){

                    Intent displayIntent = new Intent(ContactsList.this, DisplayContact.class);
                    Contact viewContact = adapter.getItem(position);
                    displayIntent.putExtra(CONTACT, (Parcelable) viewContact);
                    displayIntent.putExtra(EDIT_INDEX, position);
                    startActivity(displayIntent);
                }
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CODE_EDIT_VIEW){
            if(resultCode == RESULT_OK){
                //Obtains the new updated Contact + Index. Proceeds to send back to MainActivity onActivity Result
                Contact editMe = data.getExtras().getParcelable(CONTACT);
                int index = data.getExtras().getInt(EDIT_INDEX);

                Intent returnIntent = new Intent();
                returnIntent.putExtra(MainActivity.CONTACT, (Parcelable) editMe);
                returnIntent.putExtra(MainActivity.EDIT_INDEX, index);
                //returnIntent.putExtra(MainActivity.CONTACT_LIST, myContacts);
                setResult(RESULT_OK, returnIntent);
                finish();
            }
        }else if(requestCode == MainActivity.REQ_CODE_DELETE){

        }
    }

    private class MyListAdapter extends ArrayAdapter<Contact> {

        public MyListAdapter(){
            super(ContactsList.this, R.layout.contact_view, myContacts);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            //Make sure we have a view to work with.
            View itemView = convertView;
            if(itemView == null){
                itemView = getLayoutInflater().inflate(R.layout.contact_view, parent, false);
            }

            //Find the contact to work with.
            Contact currentContact = myContacts.get(position);

            //fill the view.
            ImageView imageView = (ImageView) itemView.findViewById(R.id.iconImage);
            imageView.setImageResource(currentContact.getAvatarID());

            TextView fnameText = (TextView) itemView.findViewById(R.id.textFName);
            fnameText.setText(currentContact.getFname());

            TextView lnameText = (TextView) itemView.findViewById(R.id.textLName);
            lnameText.setText(currentContact.getLname());

            TextView companyText = (TextView) itemView.findViewById(R.id.textCompy);
            companyText.setText(currentContact.getCompany());

            return itemView;
        }
    }




}
