package com.example.bri.hw2_group5;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Message;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateContact extends AppCompatActivity {

    private int imageID;
    static final int REQUEST_IMAGE_CAPTURE = 98;
    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 55;
    DatePickerDialog.OnDateSetListener mDateSetListener;
    static String CONTACT_KEY = "CONTACT";
    Bitmap takenPhoto;

    ArrayList<Contact> myContacts = new ArrayList<Contact>();
    private static final int MY_CAMERA_REQUEST_CODE = 500;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_contact);

        imageID = R.drawable.add_photo;


        final ImageButton takePhoto = (ImageButton) findViewById(R.id.takePhoto);
        takePhoto.setOnClickListener(new View.OnClickListener() {
            ImageButton takePhoto = (ImageButton) findViewById(R.id.takePhoto);
            @Override
            @TargetApi(Build.VERSION_CODES.M)
            public void onClick(View view) {
                if(view.getId() == takePhoto.getId()){

                    ActivityCompat.requestPermissions(CreateContact.this,
                            new String[]{Manifest.permission.CAMERA},
                            MY_PERMISSIONS_REQUEST_CAMERA);

                }
            }
        });

        final EditText bdayEdit = (EditText) findViewById(R.id.birthdayEdit);
        bdayEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if(hasFocus) {
                    Calendar cal = Calendar.getInstance();
                    int year = cal.get(Calendar.YEAR);
                    int month = cal.get(Calendar.MONTH);
                    int day = cal.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog dialog = new DatePickerDialog(CreateContact.this, mDateSetListener, year, month, day);

                    cal.add(Calendar.YEAR, -167);
                    cal.set(Calendar.DAY_OF_MONTH, 1);
                    cal.set(Calendar.MONTH, 0);
                    dialog.getDatePicker().setMinDate(cal.getTimeInMillis());
                    cal = Calendar.getInstance();

                    dialog.show();
                }

            }
        });





        bdayEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(CreateContact.this, mDateSetListener,year,month,day);

                cal.set(Calendar.YEAR, 1850);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                cal.set(Calendar.MONTH, 0);
                dialog.getDatePicker().setMinDate(cal.getTimeInMillis());
                cal = Calendar.getInstance();

                dialog.show();


            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                bdayEdit.setText(month+1 + "/" + dayOfMonth + "/" + year);
            }
        };

        //After we save, we create a new Contact Object. and Populate it to our ContactsList.
        Button save = (Button) findViewById(R.id.saveButton);
        save.setOnClickListener(new View.OnClickListener() {
            EditText fNameEdit = (EditText) findViewById(R.id.fnameEdit);
            EditText lNameEdit = (EditText) findViewById(R.id.lnameEdit);
            EditText companyEdit = (EditText) findViewById(R.id.companyEdit);
            EditText phoneEdit = (EditText) findViewById(R.id.phoneEdit);
            EditText emailEdit = (EditText) findViewById(R.id.emailEdit);
            EditText urlEdit = (EditText) findViewById(R.id.urlEdit);
            EditText addressEdit = (EditText) findViewById(R.id.addressEdit);
            EditText bdayEdit = (EditText) findViewById(R.id.birthdayEdit);
            EditText nnameEdit = (EditText) findViewById(R.id.nicknameEdit);
            EditText facebookEdit = (EditText) findViewById(R.id.facebookEdit);
            EditText twitterEdit = (EditText) findViewById(R.id.twitterEdit);
            EditText skypeEdit = (EditText) findViewById(R.id.skypeEdit);
            EditText youtubeEdit= (EditText) findViewById(R.id.youtubeEdit);
            ImageButton avatarButton = (ImageButton) findViewById(R.id.takePhoto);
            @Override
            public void onClick(View view) {

                if(view.getId() == R.id.saveButton){
                    String fName = fNameEdit.getText().toString();
                    String lName = lNameEdit.getText().toString();
                    String company = companyEdit.getText().toString();
                    String phone = phoneEdit.getText().toString();
                    String email = emailEdit.getText().toString();
                    String url = urlEdit.getText().toString();
                    String address = addressEdit.getText().toString();
                    String bday = bdayEdit.getText().toString();
                    String nname = nnameEdit.getText().toString();
                    String facebook = facebookEdit.getText().toString();
                    String twitter = twitterEdit.getText().toString();
                    String skype = skypeEdit.getText().toString();
                    String youtube = youtubeEdit.getText().toString();
                    int avatar = R.drawable.default_image;


                    if(TextUtils.isEmpty(fName) || TextUtils.isEmpty(lName) || TextUtils.isEmpty(phone) ) {
                        CharSequence text = "First name, last name, and phone required";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(CreateContact.this, text, duration);
                        toast.show();
                    }
                    else if(!Patterns.PHONE.matcher(phone).matches()){
                        CharSequence text = "Enter a valid phone";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(CreateContact.this, text, duration);
                        toast.show();

                    }
                    else if(!TextUtils.isEmpty(email) && !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                        CharSequence text = "Enter a valid email";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(CreateContact.this, text, duration);
                        toast.show();
                    }
                    else if(!TextUtils.isEmpty(bday) && Integer.parseInt(bday.substring(bday.length()-4,bday.length())) < 1850){
                        CharSequence text = "Enter a valid date";
                        Log.d("test", bday.substring(bday.length()-4,bday.length()));
                        if(TextUtils.isEmpty(bday))
                            Log.d("test", "empty");
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(CreateContact.this, text, duration);
                        toast.show();
                    }else{
                        Contact newContact = new Contact(fName, lName, company, phone, email, url, address, bday, nname, facebook, twitter, skype, youtube, avatar);
                        Intent returnIntent = new Intent();
                        returnIntent.putExtra(MainActivity.CONTACT, (Parcelable) newContact);
                        Log.d("test", "Photo pre add " + Boolean.toString(takenPhoto == null));
                        returnIntent.putExtra(MainActivity.AVATAR, takenPhoto);
                        Log.d("test", "Photo post add " + Boolean.toString(takenPhoto == null));
                        setResult(RESULT_OK, returnIntent);
                        Log.d("createContact", newContact.toString());
                        finish();
                    }
                }
            }
        });
    }



    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    }

                } else {

                    // permission denied

                }
                return;
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            takenPhoto = (Bitmap) extras.get("data");
            Log.d("test", "Photo saved " + Boolean.toString(takenPhoto == null));
            ImageButton takePhoto = (ImageButton) findViewById(R.id.takePhoto);
            takePhoto.setImageBitmap(takenPhoto);

        }
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_CANCELED) {

            ImageButton takePhoto = (ImageButton) findViewById(R.id.takePhoto);
            Bundle extras = data.getExtras();
            takenPhoto = (Bitmap) extras.get("data");
            takePhoto.setImageResource(R.drawable.default_image);

        }
    }
}
