package com.example.bri.hw2_group5;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.ImageButton;

import java.util.ArrayList;

public class DisplayContact extends AppCompatActivity{

    private ArrayList<Contact> myContacts;
    private Contact received;
    private int index;
    TextView fNameEdit;
    TextView lNameEdit;
    TextView companyEdit;
    TextView phoneEdit;
    TextView emailEdit;
    TextView urlEdit;
    TextView addressEdit;
    TextView bdayEdit;
    TextView nnameEdit;
    TextView facebookEdit;
    TextView twitterEdit;
    TextView skypeEdit;
    TextView youtubeEdit;
    ImageButton avatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_contact);

        received = (Contact) getIntent().getSerializableExtra(ContactsList.CONTACT);
        index = getIntent().getExtras().getInt(ContactsList.EDIT_INDEX);

        fNameEdit = (TextView) findViewById(R.id.fnameEdit);
        lNameEdit = (TextView) findViewById(R.id.lnameEdit);
        companyEdit = (TextView) findViewById(R.id.companyEdit);
        phoneEdit = (TextView) findViewById(R.id.phoneEdit);
        emailEdit = (TextView) findViewById(R.id.emailEdit);
        urlEdit = (TextView) findViewById(R.id.urlEdit);
        addressEdit = (TextView) findViewById(R.id.addressEdit);
        bdayEdit = (TextView) findViewById(R.id.birthdayEdit);
        nnameEdit = (TextView) findViewById(R.id.nicknameEdit);
        facebookEdit = (TextView) findViewById(R.id.facebookEdit);
        twitterEdit = (TextView) findViewById(R.id.twitterEdit);
        skypeEdit = (TextView) findViewById(R.id.skypeEdit);
        youtubeEdit = (TextView) findViewById(R.id.youtubeEdit);
        avatar = (ImageButton)  findViewById(R.id.takePhoto);


        fNameEdit.setText(getResources().getString(R.string.first) + " " + received.getFname());
        lNameEdit.setText(getResources().getString(R.string.last) + " " + received.getLname());
        companyEdit.setText(getResources().getString(R.string.company) + " " + received.getCompany());
        phoneEdit.setText(getResources().getString(R.string.phone) + " " + received.getPhone());
        emailEdit.setText(getResources().getString(R.string.email) + " " + received.getEmail());
        addressEdit.setText(getResources().getString(R.string.address) + " " + received.getAddress());
        bdayEdit.setText(getResources().getString(R.string.birthday) + " " + received.getBday());
        nnameEdit.setText(getResources().getString(R.string.nname) + " " + received.getNname());
        avatar.setImageResource(received.getAvatarID());

        //All below URL's need open website.
        //Instead on using OnClick I set 'android:autoLink="web"' for each URL textview to make them clickable.
        urlEdit.setText(getResources().getString(R.string.url) + " " + received.getUrl());
        facebookEdit.setText(getResources().getString(R.string.facebook) + " " + received.getFacebook());
        twitterEdit.setText(getResources().getString(R.string.twitter) + " " + received.getTwitter());
        skypeEdit.setText(getResources().getString(R.string.skype) + " " + received.getSkype());
        youtubeEdit.setText(getResources().getString(R.string.youtube) + " " + received.getYoutube());
    }


    /*@Override
    public void onClick(View view) {
        Intent open;
        switch (view.getId()){
            case R.id.urlEdit:
                open = new Intent(Intent.ACTION_VIEW, Uri.parse(received.getUrl()));
                startActivity(open);
                break;
            case R.id.facebookEdit:
                open = new Intent(Intent.ACTION_VIEW, Uri.parse(received.getFacebook()));
                startActivity(open);
                break;
            case R.id.twitterEdit:
                open = new Intent(Intent.ACTION_VIEW, Uri.parse(received.getTwitter()));
                startActivity(open);
                break;
            case R.id.skypeEdit:
                open = new Intent(Intent.ACTION_VIEW, Uri.parse(received.getSkype()));
                startActivity(open);
                break;
            case R.id.youtubeEdit:
                open = new Intent(Intent.ACTION_VIEW, Uri.parse(received.getYoutube()));
                startActivity(open);
                break;
        }
    }*/
}
