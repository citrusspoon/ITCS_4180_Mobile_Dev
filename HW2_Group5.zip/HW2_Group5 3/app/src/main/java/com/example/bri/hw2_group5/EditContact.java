package com.example.bri.hw2_group5;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class EditContact extends AppCompatActivity {

    DatePickerDialog.OnDateSetListener mDateSetListener;
    private ArrayList<Contact> myContacts;
    private Contact received;
    private int index;
    EditText fNameEdit;
    EditText lNameEdit;
    EditText companyEdit;
    EditText phoneEdit;
    EditText emailEdit;
    EditText urlEdit;
    EditText addressEdit;
    EditText bdayEdit;
    EditText nnameEdit;
    EditText facebookEdit;
    EditText twitterEdit;
    EditText skypeEdit;
    EditText youtubeEdit;
    ImageButton avatar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_contact);

        //Receives the contact and the position of the of the Contact.
        myContacts = (ArrayList<Contact>) getIntent().getSerializableExtra(ContactsList.CONTACT_LIST);
        received = (Contact) getIntent().getSerializableExtra(ContactsList.CONTACT);
        index = getIntent().getExtras().getInt(ContactsList.EDIT_INDEX);

        fNameEdit = (EditText) findViewById(R.id.fnameEdit);
        lNameEdit = (EditText) findViewById(R.id.lnameEdit);
        companyEdit = (EditText) findViewById(R.id.companyEdit);
        phoneEdit = (EditText) findViewById(R.id.phoneEdit);
        emailEdit = (EditText) findViewById(R.id.emailEdit);
        urlEdit = (EditText) findViewById(R.id.urlEdit);
        addressEdit = (EditText) findViewById(R.id.addressEdit);
        bdayEdit = (EditText) findViewById(R.id.birthdayEdit);
        nnameEdit = (EditText) findViewById(R.id.nicknameEdit);
        facebookEdit = (EditText) findViewById(R.id.facebookEdit);
        twitterEdit = (EditText) findViewById(R.id.twitterEdit);
        skypeEdit = (EditText) findViewById(R.id.skypeEdit);
        youtubeEdit = (EditText) findViewById(R.id.youtubeEdit);
        avatar = (ImageButton)  findViewById(R.id.takePhoto);

        fNameEdit.setText(received.getFname());
        lNameEdit.setText(received.getLname());
        companyEdit.setText(received.getCompany());
        phoneEdit.setText(received.getPhone());
        emailEdit.setText(received.getEmail());
        urlEdit.setText(received.getUrl());
        addressEdit.setText(received.getAddress());
        bdayEdit.setText(received.getBday());
        nnameEdit.setText(received.getNname());
        facebookEdit.setText(received.getFacebook());
        twitterEdit.setText(received.getTwitter());
        skypeEdit.setText(received.getSkype());
        youtubeEdit.setText(received.getYoutube());
        avatar.setImageResource(received.getAvatarID());


        final EditText bdayEdit = (EditText) findViewById(R.id.birthdayEdit);
        bdayEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if(hasFocus) {
                    Calendar cal = Calendar.getInstance();
                    int year = cal.get(Calendar.YEAR);
                    int month = cal.get(Calendar.MONTH);
                    int day = cal.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog dialog = new DatePickerDialog(EditContact.this, mDateSetListener, year, month, day);

                    cal.add(Calendar.YEAR, -167);
                    cal.set(Calendar.DAY_OF_MONTH, 1);
                    cal.set(Calendar.MONTH, 0);
                    dialog.getDatePicker().setMinDate(cal.getTimeInMillis());
                    cal = Calendar.getInstance();

                    dialog.show();
                }

            }
        });





        bdayEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(EditContact.this, mDateSetListener,year,month,day);

                cal.set(Calendar.YEAR, 1850);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                cal.set(Calendar.MONTH, 0);
                dialog.getDatePicker().setMinDate(cal.getTimeInMillis());
                cal = Calendar.getInstance();

                dialog.show();


            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                bdayEdit.setText(month+1 + "/" + dayOfMonth + "/" + year);
            }
        };






        Button saveEditButton = (Button) findViewById(R.id.saveEditButton);
        saveEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String fName = fNameEdit.getText().toString();
                String lName = lNameEdit.getText().toString();
                String company = companyEdit.getText().toString();
                String phone = phoneEdit.getText().toString();
                String email = emailEdit.getText().toString();
                String url = urlEdit.getText().toString();
                String address = addressEdit.getText().toString();
                String bday = bdayEdit.getText().toString();
                String nname = nnameEdit.getText().toString();
                String facebook = facebookEdit.getText().toString();
                String twitter = twitterEdit.getText().toString();
                String skype = skypeEdit.getText().toString();
                String youtube = youtubeEdit.getText().toString();
                int avatar = R.drawable.default_image;

                if(TextUtils.isEmpty(fName) || TextUtils.isEmpty(lName) || TextUtils.isEmpty(phone) ) {
                    CharSequence text = "First name, last name, and phone required";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(EditContact.this, text, duration);
                    toast.show();
                }
                else if(!Patterns.PHONE.matcher(phone).matches()){
                    CharSequence text = "Enter a valid phone";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(EditContact.this, text, duration);
                    toast.show();

                }
                else if(!TextUtils.isEmpty(email) && !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    CharSequence text = "Enter a valid email";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(EditContact.this, text, duration);
                    toast.show();
                }
                else if(!TextUtils.isEmpty(bday) && Integer.parseInt(bday.substring(bday.length()-4,bday.length())) < 1850){
                    CharSequence text = "Enter a valid date";
                    Log.d("test", bday.substring(bday.length()-4,bday.length()));
                    if(TextUtils.isEmpty(bday))
                        Log.d("test", "empty");
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(EditContact.this, text, duration);
                    toast.show();
                }else {

                    received.setFname(fName);
                    received.setLname(lName);
                    received.setCompany(company);
                    received.setPhone(phone);
                    received.setEmail(email);
                    received.setUrl(url);
                    received.setAddress(address);
                    received.setBday(bday);
                    received.setNname(nname);
                    received.setFacebook(facebook);
                    received.setTwitter(twitter);
                    received.setSkype(skype);
                    received.setYoutube(youtube);
                    received.setAvatarID(avatar);


                    //Sends back the updated Contact + position of the contact.
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra(ContactsList.CONTACT, (Parcelable) received);
                    returnIntent.putExtra(ContactsList.EDIT_INDEX, index);
                    returnIntent.putExtra(ContactsList.CONTACT_LIST, myContacts);
                    setResult(RESULT_OK, returnIntent);
                    Log.d("createContact", received.toString());
                    finish();
                }
            }
        });
    }
}
