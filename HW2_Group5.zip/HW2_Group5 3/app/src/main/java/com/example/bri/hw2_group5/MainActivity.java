/**
 * HW 2
 *
 * HW2_Group5.zip
 * Scott Schreiber
 * Brianna Kirkpatrick
 *
 */



package com.example.bri.hw2_group5;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public final static String CONTACT_LIST = "contactList";
    public final static String AVATAR_LIST = "avatarList";
    public final static String CONTACT = "CONTACT";
    public final static String AVATAR = "AVATAR";
    public final static String WHAT_DO = "WHAT_DO";
    public final static int REQ_CODE_ADD = 100;
    public final static int REQ_CODE_EDIT = 200;
    public final static int REQ_CODE_DELETE = 300;
    public final static int REQ_CODE_DISPLAY = 400;
    public final static String EDIT_INDEX = "Index";
    ArrayList<Contact> myContacts;
    ArrayList<Bitmap> avatarList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myContacts = new ArrayList<Contact>();
        avatarList = new ArrayList<>();

        Button createNew = (Button) findViewById(R.id.createButton);
        Button editContact = (Button) findViewById(R.id.editButton);
        Button deleteContact = (Button) findViewById(R.id.deleteButton);
        Button displayContact = (Button) findViewById(R.id.displayButton);
        Button finish = (Button) findViewById(R.id.finishButton);

        createNew.setOnClickListener(this);
        editContact.setOnClickListener(this);
        deleteContact.setOnClickListener(this);
        displayContact.setOnClickListener(this);
        finish.setOnClickListener(this);
    }

    //Maybe experiment with a Switch?
    @Override
    public void onClick(View view) {

        //Takes you to Create New Contact activity.
        if(view.getId() == R.id.createButton){
            Intent addIntent = new Intent(MainActivity.this, CreateContact.class);
            addIntent.putExtra(CONTACT_LIST, myContacts);
            addIntent.putExtra(AVATAR_LIST, avatarList);
            addIntent.putExtra(WHAT_DO, REQ_CODE_ADD);
            startActivityForResult(addIntent, REQ_CODE_ADD);
        }else if(view.getId() == R.id.editButton){
            Intent editIntent = new Intent(MainActivity.this, ContactsList.class);
            editIntent.putExtra(CONTACT_LIST, myContacts);
            editIntent.putExtra(AVATAR_LIST, avatarList);
            editIntent.putExtra(WHAT_DO, REQ_CODE_EDIT);
            startActivityForResult(editIntent, REQ_CODE_EDIT);
        }else if(view.getId() == R.id.deleteButton){
            Intent deleteIntent = new Intent(MainActivity.this, ContactsList.class);
            deleteIntent.putExtra(CONTACT_LIST, myContacts);
            deleteIntent.putExtra(WHAT_DO, REQ_CODE_DELETE);
            startActivityForResult(deleteIntent, REQ_CODE_DELETE);
        }else if(view.getId() == R.id.displayButton){
            Intent displayIntent = new Intent(MainActivity.this, ContactsList.class);
            displayIntent.putExtra(CONTACT_LIST, myContacts);
            displayIntent.putExtra(WHAT_DO, REQ_CODE_DISPLAY);
            startActivityForResult(displayIntent, REQ_CODE_DELETE);

        }else if(view.getId() == R.id.finishButton){
            finish();
            System.exit(0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQ_CODE_ADD) {
            if (resultCode == RESULT_OK) {
                Contact addMe = data.getExtras().getParcelable(CONTACT);
                Bitmap meToo = data.getExtras().getParcelable(AVATAR);
                avatarList.add(meToo);
                myContacts.add(addMe);
                Toast.makeText(this,  addMe.getFname() + " was added", Toast.LENGTH_LONG).show();
            }
        }else if(requestCode == REQ_CODE_EDIT){
            if (resultCode == RESULT_OK) {
                Contact editMe = data.getExtras().getParcelable(CONTACT);
                Bitmap meToo = data.getExtras().getParcelable(AVATAR);
                int index = data.getExtras().getInt(EDIT_INDEX);
                myContacts.set(index, editMe);
                avatarList.set(index, meToo);
            }
        }else if(requestCode == REQ_CODE_DELETE){
            if(resultCode == RESULT_OK){
                //Contact deleteMe = data.getExtras().getParcelable(CONTACT);
                int index = data.getExtras().getInt(EDIT_INDEX);
                myContacts.remove(index);
            }
        }
    }

}
